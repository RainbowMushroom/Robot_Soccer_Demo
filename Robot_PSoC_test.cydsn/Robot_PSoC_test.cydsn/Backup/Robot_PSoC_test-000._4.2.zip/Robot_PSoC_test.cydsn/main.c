/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    PWM_RESET_Write(0b00);
    PWM_L_Start();
    PWM_R_Start();
    PWM_L_Enable();
    PWM_R_Enable();

    for(;;)
    {
        /* Place your application code here. */
    }
}

/* [] END OF FILE */
