/* ========================================
 *
 * SOCCER ROBOT EMBEDDED CODE
 * VERSION 1.0
 * COMPILED FOR THE PsOC 5LP PROTOTYPING KIT
 * CY8CKIT-059 WHICH IS A CY8C5888LTI-LP097 DEVICE
 *
 * AUTHORED BY CHAY322 ET. AL. IN THE SUMMER OF 2021
 *
 * ========================================
*/
#include "project.h"
#include "encoder.h"
#include "robotmove.h"
#include "robot_ID.h"
#include <stdio.h>
#include <stdbool.h>
/* *********************************************** */
/* ************USER DEFINED MACROS**************** */
/* *********************************************** */
#define ENCODER_TIMER_ARRAY_SIZE 5
#define TRANS_BUFF_SIZE 16 //For transmitting uint and doubles over UART.  May not be necessary over the Atmel implementation
//Hardware parameters
#define ENCODER_COUNTS 200 //Encoder pulses generated in a full 360 rotation
#define WHEEL_DIAMETER 10 //Measured in centimeters
#define GEAR_RATIO 8 //Large gear teeth / small gear teeth.  Number of turns of the motor shaft which will turn the wheels a full 360
#define MOTOR_MAX_RPM 11600 //Motor rated operating speed.  This is the maximum angv the motor will operate at with our supply voltage.


/* *********************************************** */
/* ***************GLOBAL VARIABLES**************** */
/* *********************************************** */
char buffer[TRANS_BUFF_SIZE] = {}; //For transmitting uint and doubles over UART.  May not be necessary over the atmel implementation
volatile bool timerL_on = false;
volatile bool timerR_on = false;

//For storing multiple historic encoder timer values for accurate speed calculations
volatile uint16_t timerL_count[ENCODER_TIMER_ARRAY_SIZE] = {};
volatile uint16_t timerR_count[ENCODER_TIMER_ARRAY_SIZE] = {};
//Indicates which times to disregard if the timer has overflowed 
volatile bool timerL_overflows[ENCODER_TIMER_ARRAY_SIZE] = {};
volatile bool timerR_overflows[ENCODER_TIMER_ARRAY_SIZE] = {};
//For accessing the global arrays above
volatile uint8_t timerL_index = 0;
volatile uint8_t timerR_index = 0;

//For PID control
PID_DATA pid_linv;
PID_DATA pid_angv;
/* *********************************************** */
/* ***********INTERRUPT SERVICE ROUTINES********** */
/* *********************************************** */
//Encoder timer ISRS
CY_ISR(ENCODER_R_CAPT_ISR_vect){
    
}

CY_ISR(ENCODER_L_CAPT_ISR_vect){
    
}

CY_ISR(ENCODER_R_OVF_ISR_vect){
    
}

CY_ISR(ENCODER_L_OVF_ISR_vect){
    
}
//Encoder pin ISRS
CY_ISR(ENC_R_ISR_vect){
    
}

CY_ISR(ENC_L_ISR_vect){
    
}
//USART ISRS
CY_ISR(TX_ISR_vect){

    
}

CY_ISR(RX_ISR_vect){

}

/* *********************************************** */
/* **********************MAIN********************* */
/* *********************************************** */
int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    //Ensure reset lines are low initially
    PWM_RESET_Write(0b00);
    ENCODER_TMR_CAP_Write(0b00);
    ENCODER_TMR_RESET_Write(0b00);
    
    //Enable the USART
    UART_1_Start();
    UART_1_EnableRxInt();
    
    //Enable and configure all interrupts
    tx_isr_StartEx(TX_ISR_vect);
    rx_isr_StartEx(RX_ISR_vect);
    ENCODER_R_CAPT_ISR_StartEx(ENCODER_R_CAPT_ISR_vect);
    ENCODER_L_CAPT_ISR_StartEx(ENCODER_L_CAPT_ISR_vect);
    ENCODER_R_OVF_ISR_StartEx(ENCODER_R_OVF_ISR_vect);
    ENCODER_L_OVF_ISR_StartEx(ENCODER_L_OVF_ISR_vect);
    ENC_R_ISR_StartEx(ENC_R_ISR_vect);
    ENC_L_ISR_StartEx(ENC_L_ISR_vect);
    
    //Get the robot id
    uint8_t robot_id = get_robot_ID();
    
    //PWM_L_Start();
    //PWM_R_Start();
    //PWM_L_Enable();
    //PWM_R_Enable();

    for(;;){
        /* Place your application code here. */
    }
}

/* [] END OF FILE */
